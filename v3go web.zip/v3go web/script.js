"use strict";

// Lógica financeira: independente da interface e do armazenamento.
const InvoiceMath = Object.freeze({
  parseMoney(text) {
    const value = text.trim();
    if (value === "") return null;
    // Notação brasileira: 1234,56 ou 1.234,56. Sem conversões silenciosas.
    if (!/^-?(?:\d+|\d{1,3}(?:\.\d{3})+)(?:,\d{1,2})?$/.test(value)) {
      throw new Error("Informe um valor como 49,99 ou 1.234,56, com até duas casas decimais.");
    }
    const negative = value.startsWith("-");
    const [whole, fraction = ""] = value.replace(/^-/, "").replace(/\./g, "").split(",");
    const cents = Number(whole) * 100 + Number(fraction.padEnd(2, "0"));
    if (!Number.isSafeInteger(cents)) throw new Error("O valor informado é grande demais para ser calculado com precisão.");
    return negative ? -cents : cents;
  },
  sum(records) {
    return records.reduce((total, record) => {
      const result = total + (record.cents ?? 0);
      if (!Number.isSafeInteger(result)) throw new Error("A soma dos valores excede o limite de cálculo preciso.");
      return result;
    }, 0);
  },
  selectedTotal(records, categoryIds) {
    return this.sum(records.filter(record => categoryIds.has(record.categoryId ?? "uncategorized")));
  },
  calculate(records, categories = []) {
    const groups = Object.create(null);
    for (const category of [...categories, { id: "uncategorized" }]) {
      groups[category.id] = this.sum(records.filter(record => (record.categoryId ?? "uncategorized") === category.id));
    }
    return { groups, total: this.sum(records) };
  }
});

const $ = id => document.getElementById(id);
const STORAGE_KEY = "v3go.invoice.v4";
const PREVIOUS_KEYS = ["v3go.invoice.v3", "v3go.invoice.v2", "v3go.invoice.v1"];
const BASE_PERIOD = "2026-10";
const DEFAULT_CATEGORIES = [
  { id: "fixed", name: "Fixos", color: "#8865c3" },
  { id: "flexible", name: "Flexíveis", color: "#66a595" },
  { id: "moises", name: "Moisés", color: "#d7a669" },
  { id: "food", name: "Alimentação", color: "#c67d98" },
  { id: "transport", name: "Transporte", color: "#738bc6" },
  { id: "housing", name: "Moradia", color: "#81945e" },
  { id: "health", name: "Saúde", color: "#66a595" },
  { id: "education", name: "Educação", color: "#8865c3" },
  { id: "leisure", name: "Lazer", color: "#d7a669" },
  { id: "shopping", name: "Compras", color: "#c67d98" },
  { id: "other", name: "Outros", color: "#738bc6" }
];
const PALETTE = ["#8865c3", "#66a595", "#d7a669", "#738bc6", "#c67d98", "#81945e"];
const MONTHS = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
const integerFormat = new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 0 });
function decimalInput(cents) {
  const magnitude = Math.abs(cents);
  return `${cents < 0 ? "-" : ""}${Math.floor(magnitude / 100)},${String(magnitude % 100).padStart(2, "0")}`;
}
function currency(cents) {
  const magnitude = Math.abs(cents);
  return `${cents < 0 ? "-" : ""}R$\u00a0${integerFormat.format(Math.floor(magnitude / 100))},${String(magnitude % 100).padStart(2, "0")}`;
}
const normalizeName = name => name.trim().replace(/\s+/g, " ");
const compareName = name => normalizeName(name).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("pt-BR");
const validPeriod = period => typeof period === "string" && /^\d{4}-(0[1-9]|1[0-2])$/.test(period) && Number(period.slice(0, 4)) >= 1;
const newId = () => globalThis.crypto?.randomUUID?.() || `id-${Date.now()}-${Math.random().toString(36).slice(2)}`;
const emptyState = () => ({ version: 4, period: BASE_PERIOD, dueDay: 5, categories: DEFAULT_CATEGORIES.map(category => ({ ...category })), labels: [], invoices: {}, payments: {}, settlements: {}, invoiceFunding: {}, salaryDefaults: JSON.parse(JSON.stringify(DEFAULT_SALARY)), salaryMonths: {}, cardImage: null });

// Datas locais: diferenças de dias civis evitam erros de horário de verão.
const DueCalendar = Object.freeze({
  date(year, monthIndex, day) {
    const result = new Date(2000, 0, 1, 12);
    result.setFullYear(year, monthIndex, 1);
    const last = new Date(result);
    last.setMonth(last.getMonth() + 1, 0);
    result.setDate(Math.min(day, last.getDate()));
    return result;
  },
  serial(date) {
    const civil = new Date(0);
    civil.setUTCFullYear(date.getFullYear(), date.getMonth(), date.getDate());
    civil.setUTCHours(0, 0, 0, 0);
    return civil.getTime() / 86400000;
  },
  calculate(period, day, today = new Date()) {
    const [year, month] = period.split("-").map(Number);
    const due = this.date(year, month - 1, day);
    const previous = this.date(year, month - 2, day);
    const todaySerial = this.serial(today);
    const start = this.serial(previous);
    const end = this.serial(due);
    const remaining = end - todaySerial;
    const progress = Math.max(0, Math.min(100, (todaySerial - start) / (end - start) * 100));
    const status = remaining < 0 ? "past" : remaining === 0 ? "today" : remaining <= 7 ? "near" : "distant";
    const message = remaining < 0 ? `Vencimento há ${Math.abs(remaining)} ${remaining === -1 ? "dia" : "dias"}` : remaining === 0 ? "Vence hoje" : `Faltam ${remaining} ${remaining === 1 ? "dia" : "dias"}`;
    return { due, previous, remaining, progress, status, message };
  }
});
function validateOptions(options, type) {
  if (!Array.isArray(options)) throw new Error("Configurações inválidas.");
  const ids = new Set();
  const names = new Set();
  return options.map(option => {
    if (!option || typeof option.id !== "string" || !option.id || ["all", "none", "uncategorized"].includes(option.id) || ids.has(option.id) ||
        typeof option.name !== "string" || !normalizeName(option.name) || option.name.length > 60 || names.has(compareName(option.name)) ||
        compareName(option.name) === compareName(type === "categories" ? "Sem categoria" : "Sem etiqueta")) throw new Error("Opções inválidas.");
    ids.add(option.id);
    names.add(compareName(option.name));
    if (type === "categories" && !/^#[\da-f]{6}$/i.test(option.color)) throw new Error("Cor inválida.");
    return type === "categories" ? { id: option.id, name: normalizeName(option.name), color: option.color } : { id: option.id, name: normalizeName(option.name) };
  });
}
const DEFAULT_SALARY = { grossCents: 177200, first: { cents: 86600, day: 5 }, second: { cents: 75000, day: 15 } };
const METHODS = { credit: "Cartão de crédito", pix: "Pix", debit: "Débito", cash: "Dinheiro", transfer: "Transferência", other: "Outro" };
const FUNDINGS = { first: "Primeira quinzena", second: "Segunda quinzena", balance: "Saldo disponível" };
const validDate = value => {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [year, month, day] = value.split("-").map(Number);
  if (!validPeriod(value.slice(0, 7)) || day < 1 || day > 31) return false;
  const date = DueCalendar.date(year, month - 1, day);
  return date.getFullYear() === year && date.getMonth() === month - 1 && date.getDate() === day;
};
const localDateString = date => `${String(date.getFullYear()).padStart(4, "0")}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
const todayDate = () => localDateString(new Date());
const defaultRecordDate = period => todayDate().startsWith(period) ? todayDate() : `${period}-01`;
function displayDate(value) {
  if (!value) return "Não informada";
  const [year, month, day] = value.split("-");
  return `${day}/${month}/${year}`;
}
const creditRecords = (records = currentRecords()) => records.filter(record => record.type === "expense" && record.paymentMethod === "credit");
function salarySnapshot(defaults) {
  return { grossCents: defaults.grossCents, ...Object.fromEntries(["first", "second"].map(id => [id, { expectedCents: defaults[id].cents, day: defaults[id].day, received: false, actualCents: null, actualDate: null }])) };
}
function salaryFor(period = state.period) { return state.salaryMonths[period] ?? salarySnapshot(state.salaryDefaults); }
function receiptDate(period, receipt) {
  const [year, month] = period.split("-").map(Number);
  return localDateString(DueCalendar.date(year, month - 1, receipt.day));
}
const FinanceMath = Object.freeze({
  safe(value) { if (!Number.isSafeInteger(value)) throw new Error("O resultado excede o limite de cálculo preciso."); return value; },
  calculate(records, salary, settlement = null) {
    const incomes = records.filter(record => record.type === "income");
    const expenses = records.filter(record => record.type === "expense");
    const credit = expenses.filter(record => record.paymentMethod === "credit");
    const direct = expenses.filter(record => record.paymentMethod !== "credit");
    const salaryReceived = InvoiceMath.sum([salary.first, salary.second].filter(receipt => receipt.received).map(receipt => ({ cents: receipt.actualCents })));
    const salaryExpected = InvoiceMath.sum([salary.first, salary.second].filter(receipt => !receipt.received).map(receipt => ({ cents: receipt.expectedCents })));
    const incomeReceived = this.safe(InvoiceMath.sum(incomes.filter(record => record.status === "received")) + salaryReceived);
    const incomeExpected = this.safe(InvoiceMath.sum(incomes.filter(record => record.status === "expected")) + salaryExpected);
    const invoice = InvoiceMath.sum(credit);
    const invoicePaid = settlement?.cents ?? 0;
    const invoiceRemaining = settlement ? Math.max(this.safe(invoice - invoicePaid), 0) : invoice;
    const expensePaid = this.safe(InvoiceMath.sum(direct.filter(record => record.status === "paid")) + invoicePaid);
    const expensePending = this.safe(InvoiceMath.sum(direct.filter(record => record.status === "pending")) + invoiceRemaining);
    return { invoice, invoicePaid, invoiceRemaining, incomeReceived, incomeExpected, expensePaid, expensePending, spending: InvoiceMath.sum(expenses), available: this.safe(incomeReceived - expensePaid), projected: this.safe(this.safe(incomeReceived + incomeExpected) - this.safe(expensePaid + expensePending)) };
  }
});
function financeFor(period = state.period, data = state) {
  const salary = data.salaryMonths[period] ?? salarySnapshot(data.salaryDefaults);
  return FinanceMath.calculate(data.invoices[period] ?? [], salary, data.payments[period] ? data.settlements[period] : null);
}
function validateSalaryDefaults(data) {
  if (!data || !Number.isSafeInteger(data.grossCents) || data.grossCents < 0) throw new Error("Salário bruto inválido.");
  const result = { grossCents: data.grossCents };
  for (const id of ["first", "second"]) {
    const receipt = data[id];
    if (!receipt || !Number.isSafeInteger(receipt.cents) || receipt.cents < 0 || !Number.isInteger(receipt.day) || receipt.day < 1 || receipt.day > 31) throw new Error("Configuração de quinzena inválida.");
    result[id] = { cents: receipt.cents, day: receipt.day };
  }
  FinanceMath.safe(result.first.cents + result.second.cents);
  return result;
}
function validateSalaryMonth(data) {
  if (!data || !Number.isSafeInteger(data.grossCents) || data.grossCents < 0) throw new Error("Salário do mês inválido.");
  const result = { grossCents: data.grossCents };
  for (const id of ["first", "second"]) {
    const receipt = data[id];
    if (!receipt || !Number.isSafeInteger(receipt.expectedCents) || receipt.expectedCents < 0 || !Number.isInteger(receipt.day) || receipt.day < 1 || receipt.day > 31 || typeof receipt.received !== "boolean" ||
        (receipt.received && (!Number.isSafeInteger(receipt.actualCents) || receipt.actualCents < 0 || !validDate(receipt.actualDate))) ||
        (!receipt.received && (receipt.actualCents !== null || receipt.actualDate !== null))) throw new Error("Recebimento de quinzena inválido.");
    result[id] = { expectedCents: receipt.expectedCents, day: receipt.day, received: receipt.received, actualCents: receipt.actualCents, actualDate: receipt.actualDate };
  }
  FinanceMath.safe(result.first.expectedCents + result.second.expectedCents);
  return result;
}
function validateState(data) {
  if (!data || data.version !== 4 || !validPeriod(data.period) || !Number.isInteger(data.dueDay) || data.dueDay < 1 || data.dueDay > 31 ||
      !data.invoices || typeof data.invoices !== "object" || Array.isArray(data.invoices)) throw new Error("Dados salvos inválidos.");
  const categories = validateOptions(data.categories, "categories");
  const labels = validateOptions(data.labels, "labels");
  const invoices = {};
  for (const [period, records] of Object.entries(data.invoices)) {
    if (!validPeriod(period) || !Array.isArray(records)) throw new Error("Período inválido.");
    const ids = new Set();
    invoices[period] = records.map(record => {
      const income = record?.type === "income";
      if (!record || typeof record.id !== "string" || !record.id || ids.has(record.id) ||
          typeof record.description !== "string" || !record.description.trim() || record.description.length > 200 ||
          (record.categoryId !== null && !categories.some(category => category.id === record.categoryId)) ||
          (record.labelId !== null && !labels.some(label => label.id === record.labelId)) ||
          (record.cents !== null && !Number.isSafeInteger(record.cents)) || !["income", "expense"].includes(record.type) ||
          (record.date !== null && !validDate(record.date)) || !(income ? ["expected", "received"] : ["pending", "paid"]).includes(record.status) ||
          (income ? record.paymentMethod !== null : !Object.hasOwn(METHODS, record.paymentMethod)) ||
          (record.funding !== null && !Object.hasOwn(FUNDINGS, record.funding)) || (income && record.funding !== null)) throw new Error("Lançamento inválido.");
      ids.add(record.id);
      return { id: record.id, description: record.description, categoryId: record.categoryId, labelId: record.labelId, cents: record.cents, type: record.type, date: record.date, status: record.status, paymentMethod: record.paymentMethod, funding: record.funding };
    });
    InvoiceMath.calculate(creditRecords(invoices[period]), categories);
  }
  for (const field of ["payments", "settlements", "invoiceFunding", "salaryMonths"]) if (!data[field] || typeof data[field] !== "object" || Array.isArray(data[field])) throw new Error("Configuração mensal inválida.");
  const payments = {}, settlements = {}, invoiceFunding = {}, salaryMonths = {};
  for (const [period, paid] of Object.entries(data.payments)) {
    if (!validPeriod(period) || typeof paid !== "boolean") throw new Error("Pagamento inválido.");
    payments[period] = paid;
  }
  for (const [period, payment] of Object.entries(data.settlements)) {
    if (!validPeriod(period) || !payments[period] || !payment || !Number.isSafeInteger(payment.cents) || (payment.date !== null && !validDate(payment.date))) throw new Error("Pagamento da fatura inválido.");
    settlements[period] = { cents: payment.cents, date: payment.date };
  }
  for (const [period, paid] of Object.entries(payments)) if (paid && !settlements[period]) throw new Error("Fatura paga sem registro do valor.");
  for (const [period, funding] of Object.entries(data.invoiceFunding)) {
    if (!validPeriod(period) || (funding !== null && !Object.hasOwn(FUNDINGS, funding))) throw new Error("Vínculo da fatura inválido.");
    invoiceFunding[period] = funding;
  }
  const salaryDefaults = validateSalaryDefaults(data.salaryDefaults);
  for (const [period, salary] of Object.entries(data.salaryMonths)) {
    if (!validPeriod(period)) throw new Error("Período salarial inválido.");
    salaryMonths[period] = validateSalaryMonth(salary);
  }
  if (data.cardImage !== null && (typeof data.cardImage !== "string" || data.cardImage.length > 1500000 || !/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(data.cardImage))) throw new Error("Imagem salva inválida.");
  const result = { version: 4, period: data.period, dueDay: data.dueDay, categories, labels, invoices, payments, settlements, invoiceFunding, salaryDefaults, salaryMonths, cardImage: data.cardImage };
  for (const period of new Set([data.period, ...Object.keys(invoices), ...Object.keys(salaryMonths), ...Object.keys(settlements)])) financeFor(period, result);
  return result;
}
function completeCategories(categories) {
  const result = categories.map(category => ({ ...category }));
  for (const category of DEFAULT_CATEGORIES) if (!result.some(item => item.id === category.id || compareName(item.name) === compareName(category.name))) result.push({ ...category });
  return result;
}
function migratePrevious(data) {
  if (!data || ![1, 2, 3].includes(data.version)) throw new Error("Versão anterior inválida.");
  const migrated = emptyState();
  if (data.version === 1) {
    if (!validPeriod(data.period) || !Array.isArray(data.records)) throw new Error("Base antiga inválida.");
    migrated.invoices[BASE_PERIOD] = data.records.map(record => {
      if (!record || !["fixed", "flexible", "moises"].includes(record.group)) throw new Error("Categoria antiga inválida.");
      return { ...record, categoryId: record.group, labelId: null };
    });
  } else {
    migrated.period = data.period;
    migrated.dueDay = data.dueDay;
    migrated.categories = completeCategories(validateOptions(data.categories, "categories"));
    migrated.labels = data.labels;
    migrated.invoices = data.invoices;
    migrated.payments = data.version === 3 ? data.payments : {};
  }
  if (!migrated.invoices || typeof migrated.invoices !== "object" || Array.isArray(migrated.invoices)) throw new Error("Base mensal inválida.");
  const mapped = {};
  for (const [period, records] of Object.entries(migrated.invoices)) {
    if (!Array.isArray(records)) throw new Error("Lançamentos anteriores inválidos.");
    mapped[period] = records.map(record => ({ id: record.id, description: record.description, categoryId: record.categoryId, labelId: record.labelId, cents: record.cents, type: "expense", date: null, status: "pending", paymentMethod: "credit", funding: null }));
  }
  migrated.invoices = mapped;
  if (!migrated.payments || typeof migrated.payments !== "object" || Array.isArray(migrated.payments)) throw new Error("Pagamentos anteriores inválidos.");
  for (const [period, paid] of Object.entries(migrated.payments)) if (paid === true) migrated.settlements[period] = { cents: InvoiceMath.sum(mapped[period] ?? []), date: null };
  return validateState(migrated);
}

let storageBlocked = false;
let migrationApplied = false;
function storageWarning(message) {
  $("storage-warning").textContent = message;
  $("storage-warning").hidden = false;
  $("save-status").textContent = "Salvamento indisponível";
}
function loadState() {
  try {
    const current = localStorage.getItem(STORAGE_KEY);
    if (current !== null) return validateState(JSON.parse(current));
    for (const key of PREVIOUS_KEYS) {
      const previous = localStorage.getItem(key);
      if (previous !== null) {
        const migrated = migratePrevious(JSON.parse(previous));
        migrationApplied = true;
        return migrated;
      }
    }
    return emptyState();
  } catch (error) {
    storageBlocked = true;
    storageWarning("Não foi possível ler os dados salvos. Uma base vazia está visível apenas nesta sessão. O salvamento está suspenso para preservar os dados existentes. “Apagar dados salvos” permite redefinir o armazenamento com confirmação.");
    return emptyState();
  }
}
let state = loadState();
let selectedCategory = "all";
let selectedLabel = "all";
let editingId = null;
let editingPeriod = null;
let receiptEditing = null;
let settlementPeriod = null;
let currentView = "monthly";
let optionEditor = null;
let confirmationAction = null;
let toastTimer;
let customSelection = new Set();
let customAvailable = new Set();
const currentRecords = () => state.invoices[state.period] ?? [];
const optionName = (type, id) => state[type].find(option => option.id === id)?.name ?? (type === "categories" ? "Sem categoria" : "Sem etiqueta");
const categoryColor = id => state.categories.find(category => category.id === id)?.color ?? "#8e8998";
function notify(message) {
  clearTimeout(toastTimer);
  $("toast").textContent = message;
  $("toast").hidden = false;
  toastTimer = setTimeout(() => { $("toast").hidden = true; }, 4200);
}
function saveState() {
  if (storageBlocked) { notify("Alteração aplicada apenas nesta sessão. O salvamento está suspenso."); return false; }
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    $("storage-warning").hidden = true;
    $("save-status").textContent = "Salvo neste navegador";
    return true;
  } catch (error) {
    storageWarning("Não foi possível salvar no navegador. As alterações permanecem nesta sessão e podem ser perdidas ao fechar. Verifique as permissões e o espaço de armazenamento.");
    notify("Não foi possível salvar no navegador.");
    return false;
  }
}
function periodLabel(period) {
  const [year, month] = period.split("-").map(Number);
  return `${MONTHS[month - 1]} de ${year}`;
}
function resetFilters() {
  selectedCategory = "all";
  selectedLabel = "all";
  $("search").value = "";
  $("type-filter").value = "all";
}
function selectOptions(element, options, emptyLabel, selected = "", includeAll = false) {
  element.replaceChildren();
  const add = (value, label) => {
    const option = document.createElement("option");
    option.value = value;
    option.textContent = label;
    element.append(option);
  };
  if (includeAll) add("all", "Todas as etiquetas");
  add("", emptyLabel);
  options.forEach(option => add(option.id, option.name));
  element.value = [...element.options].some(option => option.value === selected) ? selected : "";
}
function renderFormOptions(category = $("group").value, label = $("record-label").value) {
  selectOptions($("group"), state.categories, "Sem categoria", category);
  selectOptions($("record-label"), state.labels, "Sem etiqueta", label);
}
function makeCell(text, className = "") {
  const cell = document.createElement("td");
  cell.textContent = text;
  cell.className = className;
  return cell;
}
function renderRow(record) {
  const row = document.createElement("tr");
  const description = makeCell("", "description-cell");
  const symbol = document.createElement("span");
  symbol.className = "record-symbol";
  symbol.setAttribute("aria-hidden", "true");
  symbol.textContent = record.description.charAt(0).toLocaleUpperCase("pt-BR");
  description.append(symbol, document.createTextNode(record.description));
  const category = makeCell("");
  const badge = document.createElement("span");
  badge.className = `badge category-badge ${["fixed", "flexible", "moises"].includes(record.categoryId) ? record.categoryId : ""}`;
  badge.style.setProperty("--category-color", categoryColor(record.categoryId));
  badge.textContent = optionName("categories", record.categoryId);
  category.append(badge);
  const type = makeCell(record.type === "income" ? "Entrada" : "Saída", `type-cell ${record.type}`);
  const date = document.createElement("small");
  date.textContent = displayDate(record.date);
  type.append(date);
  const statusText = record.status === "received" ? "Recebida" : record.status === "expected" ? "Prevista" : record.status === "paid" ? "Paga" : "Pendente";
  const status = makeCell(statusText, `status-cell ${record.status}`);
  if (record.paymentMethod) {
    const method = document.createElement("small");
    method.textContent = METHODS[record.paymentMethod];
    status.append(method);
  }
  const label = makeCell(optionName("labels", record.labelId), "label-cell");
  row.append(type, description, status, category, label, makeCell(record.cents === null ? "Sem valor" : currency(record.cents), record.cents === null ? "numeric pending" : "numeric"));
  const actions = makeCell("");
  const wrapper = document.createElement("div");
  wrapper.className = "row-actions";
  for (const [action, icon, text] of [["edit", "✎", "Editar"], ["delete", "×", "Excluir"]]) {
    const button = document.createElement("button");
    button.className = `icon-button ${action}-record`;
    button.type = "button";
    button.textContent = icon;
    button.dataset.action = action;
    button.dataset.id = record.id;
    button.setAttribute("aria-label", `${text} ${record.description}`);
    button.title = `${text} lançamento`;
    wrapper.append(button);
  }
  actions.append(wrapper);
  row.append(actions);
  return row;
}
function renderDue() {
  const info = DueCalendar.calculate(state.period, state.dueDay);
  const format = date => new Intl.DateTimeFormat("pt-BR").format(date);
  $("due-date").textContent = format(info.due);
  const confirmed = state.payments[state.period] === true;
  const finance = financeFor();
  const partial = confirmed && finance.invoiceRemaining > 0;
  const paid = confirmed && !partial;
  const message = partial ? "Pagamento parcial" : paid ? "Fatura paga" : info.message;
  const status = partial ? "partial" : paid ? "paid" : info.status;
  const progress = paid ? 100 : info.progress;
  $("due-message").textContent = message;
  $("due-message").dataset.status = status;
  $("due-progress").dataset.status = status;
  $("due-progress").setAttribute("aria-valuenow", String(Math.round(progress)));
  $("due-progress").setAttribute("aria-valuetext", paid ? "Fatura paga. Pagamento confirmado pelo usuário." : `${message}. ${Math.round(progress)}% do intervalo entre vencimentos.`);
  $("due-progress").setAttribute("aria-label", paid ? "Estado de pagamento da fatura" : "Proximidade do vencimento");
  $("due-fill").style.width = `${progress}%`;
  $("toggle-payment").textContent = partial ? "Desfazer pagamento" : paid ? "Marcar como não paga" : "Marcar como paga";
  $("toggle-payment").setAttribute("aria-pressed", String(confirmed));
  $("due-interval").textContent = `Intervalo: ${format(info.previous)} → ${format(info.due)}`;
  $("edit-invoice-payment").hidden = !confirmed;
  $("invoice-payment-note").textContent = confirmed ? `Pagamento registrado: ${currency(finance.invoicePaid)} · ${displayDate(state.settlements[state.period].date)}.${finance.invoicePaid !== finance.invoice ? ` A fatura atual difere do valor pago em ${currency(finance.invoice - finance.invoicePaid)}; confira ou corrija o pagamento.` : ""}` : "A fatura ainda não tem pagamento confirmado.";
  $("invoice-funding").value = state.invoiceFunding[state.period] ?? "";
  $("visual-card-period").textContent = periodLabel(state.period);
  $("visual-card-total").textContent = currency(finance.invoice);
  $("visual-card-status").textContent = partial ? "Pagamento parcial" : paid ? "Fatura paga" : "Fatura em aberto";
  $("credit-card").style.backgroundImage = state.cardImage ? `url("${state.cardImage}")` : "";
}
function renderManagement() {
  for (const type of ["categories", "labels"]) {
    const list = $(type === "categories" ? "category-list" : "label-list");
    list.replaceChildren();
    if (!state[type].length) {
      const empty = document.createElement("p");
      empty.textContent = type === "categories" ? "Nenhuma categoria cadastrada." : "Nenhuma etiqueta cadastrada.";
      list.append(empty);
    }
    for (const option of state[type]) {
      const row = document.createElement("div");
      row.className = "option-row";
      const name = document.createElement("span");
      name.textContent = option.name;
      if (type === "categories") name.style.setProperty("--category-color", option.color);
      const actions = document.createElement("div");
      for (const [action, label] of [["rename", "Renomear"], ["delete", "Excluir"]]) {
        const button = document.createElement("button");
        button.className = "option-action";
        button.textContent = label;
        button.dataset.type = type;
        button.dataset.id = option.id;
        button.dataset.action = action;
        button.setAttribute("aria-label", `${label} ${type === "categories" ? "categoria" : "etiqueta"} ${option.name}`);
        actions.append(button);
      }
      row.append(name, actions);
      list.append(row);
    }
  }
}
function render() {
  const records = currentRecords();
  const credit = creditRecords(records);
  const totals = InvoiceMath.calculate(credit, state.categories);
  const finance = financeFor();
  $("period-month").value = state.period.slice(5);
  $("period-year").value = Number(state.period.slice(0, 4));
  $("due-day").value = state.dueDay;
  $("total").textContent = currency(totals.total);
  $("total-caption").textContent = periodLabel(state.period);
  for (const [id, value] of [["income-expected", finance.incomeExpected], ["income-received", finance.incomeReceived], ["expense-pending", finance.expensePending], ["expense-paid", finance.expensePaid], ["available-balance", finance.available], ["projected-balance", finance.projected], ["monthly-spending", finance.spending]]) {
    $(id).textContent = currency(value);
    $(id).classList.toggle("negative-value", value < 0);
  }
  document.querySelectorAll(".category-summary").forEach(card => card.remove());
  const categories = [...state.categories];
  if (credit.some(record => record.categoryId === null)) categories.push({ id: "uncategorized", name: "Sem categoria", color: "#8e8998" });
  $("composition-bar").replaceChildren();
  $("composition-rows").replaceChildren();
  const showDistribution = totals.total > 0 && categories.every(category => totals.groups[category.id] >= 0);
  for (const category of categories) {
    const subset = credit.filter(record => (record.categoryId ?? "uncategorized") === category.id);
    const pending = subset.filter(record => record.cents === null).length;
    const dot = document.createElement("i");
    dot.className = "dot";
    dot.style.background = category.color;
    const segment = document.createElement("div");
    segment.className = "bar-segment";
    segment.style.background = category.color;
    segment.style.width = `${showDistribution ? totals.groups[category.id] / totals.total * 100 : 0}%`;
    $("composition-bar").append(segment);
    const row = document.createElement("div");
    row.className = "composition-row";
    const rowLabel = document.createElement("span");
    const rowDot = dot.cloneNode();
    rowLabel.append(rowDot, document.createTextNode(category.name));
    const value = document.createElement("strong");
    value.textContent = currency(totals.groups[category.id]);
    row.append(rowLabel, value);
    $("composition-rows").append(row);
  }
  $("composition-bar").hidden = !showDistribution;
  $("composition-note").textContent = showDistribution ? "Somente compras no cartão compõem a fatura." : "Valores somados acima. A distribuição visual exige total positivo e subtotais não negativos.";
  $("combined-label").textContent = categories.length ? categories.map(category => category.name).join(" + ") : "Nenhuma categoria cadastrada";
  $("combined-total").textContent = currency(totals.total);
  if (selectedCategory !== "all" && selectedCategory !== "none" && !state.categories.some(category => category.id === selectedCategory)) selectedCategory = "all";
  if (selectedLabel !== "all" && selectedLabel !== "" && !state.labels.some(label => label.id === selectedLabel)) selectedLabel = "all";
  $("category-tabs").replaceChildren();
  for (const category of [{ id: "all", name: "Todos" }, ...state.categories, { id: "none", name: "Sem categoria" }]) {
    const button = document.createElement("button");
    button.className = `tab${selectedCategory === category.id ? " selected" : ""}`;
    button.dataset.category = category.id;
    button.textContent = category.name;
    button.setAttribute("aria-pressed", String(selectedCategory === category.id));
    $("category-tabs").append(button);
  }
  selectOptions($("label-filter"), state.labels, "Sem etiqueta", selectedLabel, true);
  const query = compareName($("search").value);
  const selectedType = $("type-filter").value;
  const visible = records.filter(record => (selectedType === "all" || record.type === selectedType || (selectedType === "credit" && record.type === "expense" && record.paymentMethod === "credit")) && (selectedCategory === "all" || (record.categoryId ?? "none") === selectedCategory) &&
    (selectedLabel === "all" || (record.labelId ?? "") === selectedLabel) && compareName(record.description).includes(query));
  $("records").replaceChildren(...visible.map(renderRow));
  $("filtered-total").textContent = currency(InvoiceMath.sum(visible));
  $("record-count").textContent = `${records.length} ${records.length === 1 ? "lançamento" : "lançamentos"} · ${periodLabel(state.period)}${visible.length !== records.length ? ` · ${visible.length} exibidos` : ""}`;
  $("empty-state").hidden = visible.length > 0;
  $("table-note").hidden = visible.length === 0;
  document.querySelector(".table-wrap").hidden = visible.length === 0;
  $("empty-title").textContent = records.length ? "Nenhum resultado encontrado" : "Uma fatura de página nova";
  $("empty-message").textContent = records.length ? "Tente outra busca, categoria ou etiqueta." : `${periodLabel(state.period)} ainda não tem lançamentos. Adicione o primeiro para começar.`;
  $("empty-action").textContent = records.length ? "Limpar filtros" : "Novo lançamento";
  renderFormOptions();
  renderManagement();
  renderDue();
  renderCustomSum();
  renderSalary();
}
function openRecord(record = null) {
  editingId = record?.id ?? null;
  editingPeriod = state.period;
  $("record-form").reset();
  $("form-error").hidden = true;
  for (const id of ["description", "value"]) $(id).removeAttribute("aria-invalid");
  $("dialog-title").textContent = record ? "Editar lançamento" : "Novo lançamento";
  $("record-period-note").textContent = `Este lançamento pertence a ${periodLabel(editingPeriod)}. O resumo é atualizado automaticamente.`;
  $("description").value = record?.description ?? "";
  const defaultCategory = ["all", "none"].includes(selectedCategory) ? (selectedCategory === "none" ? "" : state.categories[0]?.id ?? "") : selectedCategory;
  renderFormOptions(record ? record.categoryId ?? "" : defaultCategory, record?.labelId ?? "");
  $("value").value = record?.cents == null ? "" : decimalInput(record.cents);
  $("record-type").value = record?.type ?? "expense";
  $("record-date").value = record ? record.date ?? "" : defaultRecordDate(state.period);
  $("payment-method").value = record?.paymentMethod ?? "credit";
  $("record-funding").value = record?.funding ?? "";
  updateRecordFields(record?.status ?? "pending");
  $("record-dialog").showModal();
  $("description").focus();
}
function confirmAction(title, message, label, action, transfer = null) {
  $("confirm-title").textContent = title;
  $("confirm-message").textContent = message;
  $("confirm-ok").textContent = label;
  $("transfer-field").hidden = !transfer;
  if (transfer) selectOptions($("transfer-option"), transfer.options, transfer.emptyLabel);
  confirmationAction = action;
  $("confirm-dialog").showModal();
  $("confirm-cancel").focus();
}
function openOption(type, id = null, fromRecord = false) {
  optionEditor = { type, id, fromRecord };
  $("option-form").reset();
  $("option-error").hidden = true;
  $("option-name").removeAttribute("aria-invalid");
  $("option-title").textContent = `${id ? "Renomear" : "Criar"} ${type === "categories" ? "categoria" : "etiqueta"}`;
  $("option-name").value = id ? state[type].find(option => option.id === id).name : "";
  $("option-dialog").showModal();
  $("option-name").focus();
}
function deleteOption(type, id) {
  const option = state[type].find(option => option.id === id);
  const field = type === "categories" ? "categoryId" : "labelId";
  const count = Object.values(state.invoices).flat().filter(record => record[field] === id).length;
  const singular = type === "categories" ? "categoria" : "etiqueta";
  confirmAction(`Excluir ${singular}?`, `“${option.name}” será excluída em todos os meses. ${count ? `${count} lançamento(s) usam esta opção. Escolha para onde transferir os vínculos; os lançamentos e valores serão preservados.` : "Nenhum lançamento está vinculado. Os demais dados serão preservados."}`, "Excluir opção", () => {
    const target = count ? $("transfer-option").value || null : null;
    const candidate = JSON.parse(JSON.stringify(state));
    for (const records of Object.values(candidate.invoices)) {
      for (const record of records) if (record[field] === id) record[field] = target;
    }
    candidate[type] = candidate[type].filter(item => item.id !== id);
    try {
      state = validateState(candidate);
    } catch (error) {
      notify("Não foi possível transferir os vínculos: " + error.message);
      return;
    }
    const saved = saveState();
    render();
    if (saved) notify(`${singular === "categoria" ? "Categoria" : "Etiqueta"} excluída. Lançamentos preservados.`);
  }, count ? { options: state[type].filter(item => item.id !== id), emptyLabel: type === "categories" ? "Sem categoria" : "Sem etiqueta" } : null);
}
// Consulta temporária: a seleção não faz parte dos dados financeiros persistidos.
function availableSumCategories() {
  const categories = [...state.categories];
  if (creditRecords().some(record => record.categoryId === null)) categories.push({ id: "uncategorized", name: "Sem categoria", color: "#8e8998" });
  return categories;
}
function renderCustomResult() {
  const categories = availableSumCategories();
  $("custom-period").textContent = periodLabel(state.period);
  try {
    $("custom-total").textContent = currency(InvoiceMath.selectedTotal(creditRecords(), customSelection));
    $("custom-error").hidden = true;
  } catch (error) {
    $("custom-total").textContent = "—";
    $("custom-error").textContent = error.message;
    $("custom-error").hidden = false;
  }
  const chosen = categories.filter(category => customSelection.has(category.id));
  $("custom-expression").textContent = chosen.length ? chosen.map(category => category.name).join(" + ") : "Nenhuma categoria selecionada";
}
function renderCustomSum() {
  if ($("custom-panel").hidden) return;
  const categories = availableSumCategories();
  const available = new Set(categories.map(category => category.id));
  for (const id of available) if (!customAvailable.has(id)) customSelection.add(id);
  // “Sem categoria” pode desaparecer em um mês vazio e reaparecer em outro.
  // Preserve a escolha enquanto a consulta está aberta, sem selecioná-la de novo.
  const registered = new Set([...state.categories.map(category => category.id), "uncategorized"]);
  for (const id of customSelection) if (!registered.has(id)) customSelection.delete(id);
  customAvailable = new Set([...customAvailable, ...available].filter(id => registered.has(id)));
  const focusedId = document.activeElement?.dataset.sumCategory;
  $("sum-options").replaceChildren();
  const totals = InvoiceMath.calculate(creditRecords(), state.categories);
  for (const category of categories) {
    const label = document.createElement("label");
    label.className = "sum-option";
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.dataset.sumCategory = category.id;
    checkbox.checked = customSelection.has(category.id);
    const name = document.createElement("span");
    name.textContent = category.name;
    const subtotal = document.createElement("strong");
    subtotal.textContent = currency(totals.groups[category.id]);
    label.append(checkbox, name, subtotal);
    $("sum-options").append(label);
    if (category.id === focusedId) checkbox.focus();
  }
  $("sum-empty").hidden = categories.length > 0;
  renderCustomResult();
}
$("toggle-payment").addEventListener("click", () => {
  if (!state.payments[state.period]) { openSettlement(); return; }
  const period = state.period;
  confirmAction("Desfazer pagamento da fatura?", "O registro de saída de dinheiro será desfeito somente para este mês. As compras permanecem intactas.", "Marcar como não paga", () => {
    state.payments[period] = false;
    delete state.settlements[period];
    const saved = saveState();
    render();
    if (saved) notify("Pagamento desfeito para este mês.");
  });
});
$("sum-categories").addEventListener("click", () => {
  customAvailable = new Set(availableSumCategories().map(category => category.id));
  customSelection = new Set(customAvailable);
  $("custom-panel").hidden = false;
  $("sum-categories").setAttribute("aria-expanded", "true");
  renderCustomSum();
  $("custom-panel").scrollIntoView({ behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "nearest" });
  $("custom-title").focus({ preventScroll: true });
});
$("close-sum").addEventListener("click", () => {
  $("custom-panel").hidden = true;
  $("sum-categories").setAttribute("aria-expanded", "false");
  $("sum-categories").focus();
});
$("sum-options").addEventListener("change", event => {
  const checkbox = event.target.closest("input[data-sum-category]");
  if (!checkbox) return;
  if (checkbox.checked) customSelection.add(checkbox.dataset.sumCategory);
  else customSelection.delete(checkbox.dataset.sumCategory);
  renderCustomResult();
});
for (const [id, select] of [["sum-all", true], ["sum-none", false]]) $(id).addEventListener("click", () => {
  customSelection = select ? new Set(availableSumCategories().map(category => category.id)) : new Set();
  renderCustomSum();
});
MONTHS.forEach((name, index) => {
  const option = document.createElement("option");
  option.value = String(index + 1).padStart(2, "0");
  option.textContent = name;
  $("period-month").append(option);
});
$("add-record").addEventListener("click", () => openRecord());
$("empty-action").addEventListener("click", () => { if (currentRecords().length) { resetFilters(); render(); } else openRecord(); });
for (const id of ["close-dialog", "cancel-dialog"]) $(id).addEventListener("click", () => $("record-dialog").close());
$("record-form").addEventListener("submit", event => {
  event.preventDefault();
  $("form-error").hidden = true;
  for (const id of ["description", "value"]) $(id).removeAttribute("aria-invalid");
  let invalidField = "description";
  try {
    const description = $("description").value.trim();
    if (!description) throw new Error("Preencha a descrição do lançamento.");
    if (description.length > 200) throw new Error("A descrição deve ter até 200 caracteres.");
    invalidField = "value";
    const cents = InvoiceMath.parseMoney($("value").value);
    const categoryId = $("group").value || null;
    const labelId = $("record-label").value || null;
    if (categoryId && !state.categories.some(category => category.id === categoryId)) throw new Error("Selecione uma categoria válida.");
    if (labelId && !state.labels.some(label => label.id === labelId)) throw new Error("Selecione uma etiqueta válida.");
    const type = $("record-type").value;
    const date = $("record-date").value || null;
    const previousRecord = (state.invoices[editingPeriod] ?? []).find(item => item.id === editingId);
    invalidField = "record-date";
    if (!validDate(date) && !(previousRecord && previousRecord.date === null && date === null)) throw new Error("Preencha uma data válida para o lançamento.");
    const status = $("record-status").value;
    if (["received", "paid"].includes(status) && cents === null) { invalidField = "value"; throw new Error("Um valor confirmado precisa ser preenchido."); }
    const paymentMethod = type === "expense" ? $("payment-method").value : null;
    const funding = type === "expense" && paymentMethod !== "credit" ? $("record-funding").value || null : null;
    const record = { id: editingId ?? newId(), description, categoryId, labelId, cents, type, date, status, paymentMethod, funding };
    const previous = state.invoices[editingPeriod] ?? [];
    const records = editingId ? previous.map(item => item.id === editingId ? record : item) : [...previous, record];
    const candidate = JSON.parse(JSON.stringify(state));
    candidate.invoices[editingPeriod] = records;
    state = validateState(candidate);
    const saved = saveState();
    $("record-dialog").close();
    resetFilters();
    render();
    if (saved) notify(editingId ? "Lançamento atualizado." : "Lançamento adicionado.");
  } catch (error) {
    $("form-error").textContent = error.message;
    $("form-error").hidden = false;
    $(invalidField).setAttribute("aria-invalid", "true");
    $(invalidField).focus();
  }
});
$("records").addEventListener("click", event => {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  const record = currentRecords().find(item => item.id === button.dataset.id);
  if (!record) return;
  if (button.dataset.action === "edit") openRecord(record);
  else {
    const period = state.period;
    confirmAction("Excluir lançamento?", `“${record.description}” será removido somente de ${periodLabel(period)}.`, "Excluir lançamento", () => {
      state.invoices[period] = state.invoices[period].filter(item => item.id !== record.id);
      const saved = saveState();
      render();
      if (saved) notify("Lançamento excluído deste mês.");
      $("add-record").focus();
    });
  }
});
$("category-tabs").addEventListener("click", event => {
  const button = event.target.closest("button[data-category]");
  if (!button) return;
  selectedCategory = button.dataset.category;
  render();
});
$("label-filter").addEventListener("change", () => { selectedLabel = $("label-filter").value; render(); });
$("search").addEventListener("input", render);
function changePeriod() {
  const year = $("period-year").value;
  const period = `${year.padStart(4, "0")}-${$("period-month").value}`;
  if (!/^\d{1,4}$/.test(year) || !validPeriod(period)) { render(); notify("Selecione um mês e um ano entre 1 e 9999."); return; }
  state.period = period;
  // Nenhuma importação nem cópia: um mês ainda inexistente é uma lista vazia.
  resetFilters();
  saveState();
  render();
}
$("period-month").addEventListener("change", changePeriod);
$("period-year").addEventListener("change", changePeriod);
$("due-form").addEventListener("submit", event => {
  event.preventDefault();
  const raw = $("due-day").value;
  const day = Number(raw);
  if (!/^\d{1,2}$/.test(raw) || !Number.isInteger(day) || day < 1 || day > 31) {
    $("due-error").textContent = "Informe um dia entre 1 e 31.";
    $("due-error").hidden = false;
    $("due-day").setAttribute("aria-invalid", "true");
    $("due-day").focus();
    return;
  }
  $("due-error").hidden = true;
  $("due-day").removeAttribute("aria-invalid");
  state.dueDay = day;
  const saved = saveState();
  render();
  if (saved) notify("Dia de vencimento atualizado para todos os meses.");
});
for (const [id, type, fromRecord] of [["create-category", "categories", true], ["create-label", "labels", true], ["manage-add-category", "categories", false], ["manage-add-label", "labels", false]]) {
  $(id).addEventListener("click", () => openOption(type, null, fromRecord));
}
for (const id of ["option-close", "option-cancel"]) $(id).addEventListener("click", () => $("option-dialog").close());
$("option-form").addEventListener("submit", event => {
  event.preventDefault();
  const { type, id, fromRecord } = optionEditor;
  const name = normalizeName($("option-name").value);
  const emptyLabel = type === "categories" ? "Sem categoria" : "Sem etiqueta";
  let message = "";
  if (!name) message = "Preencha o nome da opção.";
  else if (name.length > 60) message = "Use um nome com até 60 caracteres.";
  else if (compareName(name) === compareName(emptyLabel)) message = `“${emptyLabel}” é uma opção reservada.`;
  else if (state[type].some(option => option.id !== id && compareName(option.name) === compareName(name))) message = "Já existe uma opção com este nome.";
  if (message) {
    $("option-error").textContent = message;
    $("option-error").hidden = false;
    $("option-name").setAttribute("aria-invalid", "true");
    $("option-name").focus();
    return;
  }
  const optionId = id ?? newId();
  if (id) state[type].find(option => option.id === id).name = name;
  else state[type].push({ id: optionId, name, ...(type === "categories" ? { color: PALETTE[state.categories.length % PALETTE.length] } : {}) });
  const saved = saveState();
  $("option-dialog").close();
  render();
  if (fromRecord) $(type === "categories" ? "group" : "record-label").value = optionId;
  if (saved) notify(id ? "Nome atualizado em todos os meses." : `${type === "categories" ? "Categoria criada" : "Etiqueta criada"}.`);
});
for (const id of ["category-list", "label-list"]) $(id).addEventListener("click", event => {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  if (button.dataset.action === "rename") openOption(button.dataset.type, button.dataset.id);
  else deleteOption(button.dataset.type, button.dataset.id);
});
$("confirm-cancel").addEventListener("click", () => $("confirm-dialog").close());
$("confirm-ok").addEventListener("click", () => {
  const action = confirmationAction;
  confirmationAction = null;
  $("confirm-dialog").close();
  action?.();
});
$("confirm-dialog").addEventListener("cancel", () => { confirmationAction = null; });
$("clear-data").addEventListener("click", () => confirmAction("Apagar os dados salvos?", `Todos os lançamentos, pagamentos e recebimentos de salário de TODOS os meses serão apagados. Categorias, etiquetas, salário padrão, imagem e dia de vencimento serão preservados.${storageBlocked ? " Os dados ilegíveis serão redefinidos após esta confirmação." : ""}`, "Apagar dados", () => {
  if (storageBlocked) state = emptyState();
  state.invoices = {};
  state.payments = {};
  state.settlements = {};
  state.invoiceFunding = {};
  state.salaryMonths = {};
  storageBlocked = false;
  const saved = saveState();
  resetFilters();
  render();
  if (saved) notify("Lançamentos e pagamentos de todos os meses apagados. Configurações preservadas.");
}));
function updateRecordFields(preferredStatus = $("record-status").value) {
  const income = $("record-type").value === "income";
  const credit = !income && $("payment-method").value === "credit";
  $("payment-method-field").hidden = income;
  $("record-funding-field").hidden = income || credit;
  $("credit-method-note").hidden = !credit;
  const options = income ? [["expected", "Prevista"], ["received", "Recebida"]] : [["pending", "Pendente"], ["paid", credit ? "Paga no cartão (sem saída de dinheiro)" : "Paga"]];
  $("record-status").replaceChildren();
  for (const [value, name] of options) {
    const option = document.createElement("option");
    option.value = value;
    option.textContent = name;
    $("record-status").append(option);
  }
  $("record-status").value = options.some(([value]) => value === preferredStatus) ? preferredStatus : options[0][0];
}
function setView(view) {
  currentView = view;
  for (const id of ["monthly", "salary"]) {
    const active = id === view;
    $(id + "-view").hidden = !active;
    $("tab-" + id).setAttribute("aria-selected", String(active));
    $("tab-" + id).tabIndex = active ? 0 : -1;
  }
}
function nonnegativeMoney(text, label) {
  const cents = InvoiceMath.parseMoney(text);
  if (cents === null || cents < 0) throw new Error(`Preencha ${label} com um valor maior ou igual a zero.`);
  return cents;
}
function validDayInput(value) {
  if (!/^\d{1,2}$/.test(value) || Number(value) < 1 || Number(value) > 31) throw new Error("Os dias devem estar entre 1 e 31.");
  return Number(value);
}
function monthCommitments() {
  const records = currentRecords();
  const result = records.filter(record => record.type === "expense" && record.paymentMethod !== "credit").map(record => ({ id: record.id, description: record.description, cents: record.cents, date: record.date, funding: record.funding, paid: record.status === "paid" }));
  const finance = financeFor();
  if (creditRecords().length || state.payments[state.period]) {
    const info = DueCalendar.calculate(state.period, state.dueDay);
    result.push({ id: "invoice", description: "Pagamento da fatura", cents: FinanceMath.safe(finance.invoicePaid + finance.invoiceRemaining), date: localDateString(info.due), funding: state.invoiceFunding[state.period] ?? null, paid: state.payments[state.period] === true && finance.invoiceRemaining === 0, partial: state.payments[state.period] === true && finance.invoiceRemaining > 0, actualDate: state.settlements[state.period]?.date ?? null });
  }
  return result.sort((a, b) => (a.date ?? "9999-12-31").localeCompare(b.date ?? "9999-12-31"));
}
function commitmentElement(commitment, receipt = null) {
  const row = document.createElement("div");
  row.className = "commitment-row";
  const title = document.createElement("strong");
  title.textContent = commitment.description;
  const detail = document.createElement("small");
  detail.textContent = `${commitment.id === "invoice" ? "Vencimento" : "Data"}: ${displayDate(commitment.date)} · ${commitment.partial ? "Pagamento parcial" : commitment.paid ? "Paga" : "Pendente"}${commitment.actualDate ? ` · pagamento em ${displayDate(commitment.actualDate)}` : ""}`;
  const amount = document.createElement("span");
  amount.className = "commitment-amount";
  amount.textContent = commitment.cents === null ? "Valor não definido" : currency(commitment.cents);
  const select = document.createElement("select");
  select.setAttribute("aria-label", `Cobrir ${commitment.description} com`);
  select.dataset.commitment = commitment.id;
  for (const [value, text] of [["", "Ainda não vinculado"], ["balance", "Saldo disponível"], ["first", "Primeira quinzena"], ["second", "Segunda quinzena"]]) {
    const option = document.createElement("option");
    option.value = value;
    option.textContent = text;
    select.append(option);
  }
  select.value = commitment.funding ?? "";
  row.append(title, amount, detail, select);
  if (receipt) {
    const coverageDate = receipt.received ? receipt.actualDate : receiptDate(state.period, receipt);
    if (commitment.date && commitment.date < coverageDate) {
      const warning = document.createElement("p");
      warning.className = "timing-warning";
      warning.textContent = "Atenção: este compromisso vence antes da data deste recebimento.";
      row.append(warning);
    }
  }
  return row;
}
function renderSalary() {
  const salary = salaryFor();
  $("salary-period").textContent = `${periodLabel(state.period)} · Configuração e recebimentos deste período`;
  $("salary-gross").value = decimalInput(salary.grossCents);
  for (const id of ["first", "second"]) {
    $("salary-" + id).value = decimalInput(salary[id].expectedCents);
    $("salary-" + id + "-day").value = salary[id].day;
  }
  const expected = FinanceMath.safe(salary.first.expectedCents + salary.second.expectedCents);
  $("salary-net").textContent = currency(expected);
  $("salary-difference").textContent = currency(FinanceMath.safe(salary.grossCents - expected));
  $("salary-receipts").replaceChildren();
  $("quarter-plans").replaceChildren();
  const commitments = monthCommitments();
  const ordered = ["first", "second"].sort((a, b) => salary[a].day - salary[b].day);
  for (const id of ordered) {
    const receipt = salary[id];
    const card = document.createElement("section");
    card.className = "panel receipt-card";
    const heading = document.createElement("div");
    heading.className = "receipt-heading";
    const name = document.createElement("h3");
    name.textContent = FUNDINGS[id];
    const status = document.createElement("span");
    status.className = `receipt-status ${receipt.received ? "received" : "expected"}`;
    status.textContent = receipt.received ? "Recebida" : "Prevista";
    heading.append(name, status);
    const expectedValue = document.createElement("p");
    expectedValue.textContent = `Prevista: ${currency(receipt.expectedCents)} · ${displayDate(receiptDate(state.period, receipt))}`;
    const actual = document.createElement("div");
    actual.className = "amount";
    actual.textContent = currency(receipt.received ? receipt.actualCents : 0);
    const date = document.createElement("p");
    date.className = "small-note";
    date.textContent = receipt.received ? `Recebida em ${displayDate(receipt.actualDate)}` : "Ainda não recebida. Você pode confirmar antes da data prevista.";
    const actions = document.createElement("div");
    actions.className = "receipt-actions";
    const confirm = document.createElement("button");
    confirm.className = "button primary";
    confirm.dataset.receipt = id;
    confirm.textContent = receipt.received ? "Corrigir recebimento" : "Marcar como recebida";
    confirm.setAttribute("aria-label", `${confirm.textContent}: ${FUNDINGS[id]}`);
    actions.append(confirm);
    if (receipt.received) {
      const undo = document.createElement("button");
      undo.className = "button secondary";
      undo.dataset.undoReceipt = id;
      undo.textContent = "Desfazer";
      undo.setAttribute("aria-label", `Desfazer recebimento: ${FUNDINGS[id]}`);
      actions.append(undo);
    }
    card.append(heading, expectedValue, actual, date, actions);
    $("salary-receipts").append(card);
    const selected = commitments.filter(commitment => commitment.funding === id);
    const committed = InvoiceMath.sum(selected);
    const reference = receipt.received ? receipt.actualCents : receipt.expectedCents;
    const left = FinanceMath.safe(reference - committed);
    const plan = document.createElement("section");
    plan.className = `quarter-plan${left < 0 || committed > receipt.expectedCents ? " over-budget" : ""}`;
    const planHeading = document.createElement("h3");
    planHeading.textContent = `${FUNDINGS[id]} · ${displayDate(receiptDate(state.period, receipt))}`;
    const text = document.createElement("p");
    text.textContent = `Previsto ${currency(receipt.expectedCents)} · Recebido ${currency(receipt.received ? receipt.actualCents : 0)} · Compromissos ${currency(committed)}`;
    const result = document.createElement("strong");
    result.className = "plan-result";
    result.textContent = left < 0 ? `Faltam ${currency(-left)}` : `Sobram ${currency(left)}`;
    plan.append(planHeading, text, result);
    if (committed > receipt.expectedCents) {
      const warning = document.createElement("p");
      warning.className = "timing-warning";
      warning.textContent = "Os compromissos ultrapassam o recebimento previsto.";
      plan.append(warning);
    }
    if (selected.some(commitment => commitment.cents === null)) {
      const note = document.createElement("p");
      note.className = "timing-warning";
      note.textContent = "Há compromissos sem valor definido, fora do total.";
      plan.append(note);
    }
    if (!selected.length) {
      const empty = document.createElement("p");
      empty.textContent = "Nenhum compromisso vinculado a este recebimento.";
      plan.append(empty);
    }
    selected.forEach(commitment => plan.append(commitmentElement(commitment, receipt)));
    $("quarter-plans").append(plan);
  }
  for (const [id, funding] of [["unassigned-commitments", null], ["balance-commitments", "balance"]]) {
    $(id).replaceChildren();
    const matching = commitments.filter(commitment => commitment.funding === funding);
    matching.forEach(commitment => $(id).append(commitmentElement(commitment)));
    if (!matching.length) {
      const empty = document.createElement("p");
      empty.textContent = "Nenhum compromisso nesta área.";
      $(id).append(empty);
    }
  }
  const balancePending = InvoiceMath.sum(commitments.filter(commitment => commitment.funding === "balance").map(commitment => ({ cents: commitment.id === "invoice" ? financeFor().invoiceRemaining : commitment.paid ? 0 : commitment.cents })));
  $("balance-plan-note").textContent = `Disponível no mês: ${currency(financeFor().available)} · Pendentes vinculados: ${currency(balancePending)}. O disponível já desconta valores pagos.`;
}
function openReceipt(id) {
  receiptEditing = { id, period: state.period };
  const receipt = salaryFor()[id];
  $("receipt-title").textContent = receipt.received ? "Corrigir recebimento" : "Confirmar recebimento";
  $("receipt-context").textContent = `${FUNDINGS[id]} · ${periodLabel(state.period)}. Você pode confirmar um recebimento antecipado, sem mudar a data prevista.`;
  $("receipt-value").value = decimalInput(receipt.received ? receipt.actualCents : receipt.expectedCents);
  $("receipt-date").value = receipt.received ? receipt.actualDate : todayDate();
  $("receipt-error").hidden = true;
  $("receipt-dialog").showModal();
  $("receipt-value").focus();
}
function openSettlement() {
  settlementPeriod = state.period;
  const existing = state.settlements[state.period];
  $("settlement-context").textContent = `${periodLabel(state.period)} · Fatura atual ${currency(financeFor().invoice)}. Este pagamento sai do saldo sem gerar uma segunda despesa.`;
  $("settlement-value").value = decimalInput(existing?.cents ?? financeFor().invoice);
  $("settlement-date").value = existing?.date ?? todayDate();
  $("settlement-error").hidden = true;
  $("settlement-dialog").showModal();
  $("settlement-value").focus();
}
for (const view of ["monthly", "salary"]) {
  $("tab-" + view).addEventListener("click", () => setView(view));
  $("tab-" + view).addEventListener("keydown", event => {
    if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
    event.preventDefault();
    const next = event.key === "Home" ? "monthly" : event.key === "End" ? "salary" : currentView === "salary" ? "monthly" : "salary";
    setView(next);
    $("tab-" + next).focus();
  });
}
$("nav-salary").addEventListener("click", event => { event.preventDefault(); setView("salary"); $("tab-salary").scrollIntoView({ block: "start" }); });
document.querySelector('.nav-link[href="#lancamentos"]').addEventListener("click", () => setView("monthly"));
$("record-type").addEventListener("change", () => updateRecordFields());
$("payment-method").addEventListener("change", () => updateRecordFields());
$("type-filter").addEventListener("change", render);
$("edit-invoice-payment").addEventListener("click", openSettlement);
$("invoice-funding").addEventListener("change", () => {
  state.invoiceFunding[state.period] = $("invoice-funding").value || null;
  saveState();
  renderSalary();
});
$("salary-config").addEventListener("submit", event => {
  event.preventDefault();
  try {
    const defaults = validateSalaryDefaults({ grossCents: nonnegativeMoney($("salary-gross").value, "o salário bruto"), first: { cents: nonnegativeMoney($("salary-first").value, "a primeira quinzena"), day: validDayInput($("salary-first-day").value) }, second: { cents: nonnegativeMoney($("salary-second").value, "a segunda quinzena"), day: validDayInput($("salary-second-day").value) } });
    const candidate = JSON.parse(JSON.stringify(state));
    const current = salaryFor();
    candidate.salaryMonths[state.period] = { grossCents: defaults.grossCents, first: { ...current.first, expectedCents: defaults.first.cents, day: defaults.first.day }, second: { ...current.second, expectedCents: defaults.second.cents, day: defaults.second.day } };
    candidate.salaryDefaults = defaults;
    state = validateState(candidate);
    $("salary-config-error").hidden = true;
    const saved = saveState();
    render();
    if (saved) notify("Configuração salva para este mês e para os próximos ainda não configurados.");
  } catch (error) {
    $("salary-config-error").textContent = error.message;
    $("salary-config-error").hidden = false;
  }
});
$("salary-receipts").addEventListener("click", event => {
  const confirm = event.target.closest("button[data-receipt]");
  if (confirm) { openReceipt(confirm.dataset.receipt); return; }
  const undo = event.target.closest("button[data-undo-receipt]");
  if (!undo) return;
  const period = state.period, id = undo.dataset.undoReceipt;
  confirmAction("Desfazer recebimento?", `Somente ${FUNDINGS[id]} de ${periodLabel(period)} voltará a ser prevista. A fatura não será alterada.`, "Desfazer recebimento", () => {
    state.salaryMonths[period][id] = { ...state.salaryMonths[period][id], received: false, actualCents: null, actualDate: null };
    const saved = saveState();
    render();
    if (saved) notify("Confirmação de recebimento desfeita.");
  });
});
$("receipt-form").addEventListener("submit", event => {
  event.preventDefault();
  try {
    const value = nonnegativeMoney($("receipt-value").value, "o valor recebido");
    const date = $("receipt-date").value;
    if (!validDate(date)) throw new Error("Informe uma data real de recebimento válida.");
    const { id, period } = receiptEditing;
    const candidate = JSON.parse(JSON.stringify(state));
    const salary = salaryFor(period);
    candidate.salaryMonths[period] = { ...salary, [id]: { ...salary[id], received: true, actualCents: value, actualDate: date } };
    state = validateState(candidate);
    const saved = saveState();
    $("receipt-dialog").close();
    render();
    if (saved) notify("Quinzena recebida. Saldo atualizado sem duplicar a entrada.");
  } catch (error) {
    $("receipt-error").textContent = error.message;
    $("receipt-error").hidden = false;
  }
});
$("settlement-form").addEventListener("submit", event => {
  event.preventDefault();
  try {
    const cents = InvoiceMath.parseMoney($("settlement-value").value);
    if (cents === null) throw new Error("Preencha o valor pago.");
    const date = $("settlement-date").value;
    if (!validDate(date)) throw new Error("Informe uma data válida para o pagamento.");
    const candidate = JSON.parse(JSON.stringify(state));
    candidate.payments[settlementPeriod] = true;
    candidate.settlements[settlementPeriod] = { cents, date };
    state = validateState(candidate);
    const saved = saveState();
    $("settlement-dialog").close();
    render();
    if (saved) notify("Pagamento da fatura registrado sem criar outra despesa.");
  } catch (error) {
    $("settlement-error").textContent = error.message;
    $("settlement-error").hidden = false;
  }
});
for (const [dialog, prefix] of [["receipt-dialog", "receipt"], ["settlement-dialog", "settlement"]]) for (const suffix of ["close", "cancel"]) $(prefix + "-" + suffix).addEventListener("click", () => $(dialog).close());
$("salary-view").addEventListener("change", event => {
  const select = event.target.closest("select[data-commitment]");
  if (!select) return;
  const funding = select.value || null;
  if (select.dataset.commitment === "invoice") state.invoiceFunding[state.period] = funding;
  else {
    const record = currentRecords().find(item => item.id === select.dataset.commitment);
    if (!record) return;
    record.funding = funding;
  }
  saveState();
  render();
});
$("card-upload-button").addEventListener("keydown", event => {
  if (!["Enter", " "].includes(event.key)) return;
  event.preventDefault();
  $("card-upload").click();
});
$("card-upload").addEventListener("change", async () => {
  const file = $("card-upload").files?.[0];
  if (!file) return;
  try {
    if (!["image/jpeg", "image/png", "image/webp", "image/avif"].includes(file.type) || file.size > 10 * 1024 * 1024) throw new Error("Envie uma imagem PNG, JPEG, WebP ou AVIF de até 10 MB.");
    const url = URL.createObjectURL(file);
    const image = new Image();
    try {
      image.src = url;
      await image.decode();
      if (!image.naturalWidth || image.naturalWidth * image.naturalHeight > 40000000) throw new Error("A imagem é grande demais. Use uma versão com até 40 megapixels.");
      const scale = Math.min(1, 1280 / image.naturalWidth, 1280 / image.naturalHeight);
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(image.naturalWidth * scale);
      canvas.height = Math.round(image.naturalHeight * scale);
      const context = canvas.getContext("2d");
      context.fillStyle = "#302343";
      context.fillRect(0, 0, canvas.width, canvas.height);
      context.drawImage(image, 0, 0, canvas.width, canvas.height);
      const encoded = canvas.toDataURL("image/jpeg", .85);
      if (encoded.length > 1500000) throw new Error("A imagem não coube no armazenamento. Envie uma imagem menor.");
      if (storageBlocked) throw new Error("O salvamento está suspenso. Recupere o armazenamento antes de personalizar o cartão.");
      const previous = state.cardImage;
      state.cardImage = encoded;
      if (!saveState()) { state.cardImage = previous; throw new Error("Não foi possível salvar a imagem. Os dados financeiros foram preservados."); }
      $("card-image-error").hidden = true;
      renderDue();
      notify("Imagem do cartão salva neste navegador.");
    } finally { URL.revokeObjectURL(url); }
  } catch (error) {
    $("card-image-error").textContent = error.message;
    $("card-image-error").hidden = false;
  }
  $("card-upload").value = "";
});
$("restore-card").addEventListener("click", () => {
  const previous = state.cardImage;
  state.cardImage = null;
  if (!saveState()) { state.cardImage = previous; return; }
  $("card-image-error").hidden = true;
  renderDue();
  notify("Imagem padrão restaurada.");
});

render();
if (!storageBlocked) {
  const saved = saveState();
  if (saved && migrationApplied) notify("Dados salvos preservados na nova versão.");
}
// Recalcula quando a aba volta ao primeiro plano e atravessa a meia-noite local.
setInterval(renderDue, 60000);
document.addEventListener("visibilitychange", () => { if (!document.hidden) renderDue(); });
